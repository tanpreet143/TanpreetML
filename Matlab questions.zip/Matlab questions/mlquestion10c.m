
fig3 = imread('fig3.jpg');


gray_pixels = fig3(:);


save('gray_pixels.mat', 'gray_pixels');